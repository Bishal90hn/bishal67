import requests
import feedparser
from googletrans import Translator
from bs4 import BeautifulSoup
from time import sleep
import random
from telegram import Bot

# Telegram Bot Token
BOT_TOKEN = "7980947590:AAFrmaCIFajzk0NjR-aZE7PwuIGrs45WGGo"
CHANNEL_ID = "@Aisamachar24"

# RSS Feeds
RSS_FEEDS = [
    "http://feeds.bbci.co.uk/hindi/rss.xml",
    "https://www.thehindu.com/feeder/default.rss",
    "https://timesofindia.indiatimes.com/rssfeeds/1221656.cms",
    "https://feeds.feedburner.com/ndtvnews-top-stories",
    "https://www.aljazeera.com/xml/rss/all.xml"
]

# Translator
translator = Translator()

# Proxy Setup
PROXIES = {
    "http": "http://your_proxy_here",
    "https": "https://your_proxy_here"
}

# Function to fetch news from RSS
def fetch_rss_news():
    news_list = []
    for feed in RSS_FEEDS:
        news_feed = feedparser.parse(feed)
        for entry in news_feed.entries[:5]:  # Get top 5 news from each feed
            news_list.append({
                "title": entry.title,
                "link": entry.link,
                "summary": entry.summary if hasattr(entry, "summary") else ""
            })
    return news_list

# Function to scrape Google Trends
def scrape_google_trends():
    url = "https://trends.google.com/trends/trendingsearches/daily/rss?geo=IN"
    response = requests.get(url, proxies=PROXIES)
    soup = BeautifulSoup(response.content, "xml")
    trends = []
    for item in soup.find_all("item")[:5]:  # Top 5 trends
        trends.append({
            "title": item.title.text,
            "link": item.link.text,
            "summary": item.description.text
        })
    return trends

# Function to translate news to Hindi
def translate_to_hindi(news_list):
    translated_news = []
    for news in news_list:
        try:
            title = translator.translate(news["title"], src="auto", dest="hi").text
            summary = translator.translate(news["summary"], src="auto", dest="hi").text
        except Exception as e:
            title = news["title"]
            summary = news["summary"]
        translated_news.append({
            "title": title,
            "link": news["link"],
            "summary": summary
        })
    return translated_news

# Function to post news on Telegram
def post_to_telegram(news):
    bot = Bot(token=BOT_TOKEN)
    for item in news:
        message = f"📰 {item['title']}\n\n{item['summary']}\n\n🔗 [Read More]({item['link']})"
        bot.send_message(chat_id=CHANNEL_ID, text=message, parse_mode="Markdown")
        sleep(random.randint(10, 30))  # Random delay between posts

# Main Function
if __name__ == "__main__":
    while True:
        rss_news = fetch_rss_news()
        trends_news = scrape_google_trends()
        all_news = rss_news + trends_news
        hindi_news = translate_to_hindi(all_news)
        post_to_telegram(hindi_news)
        sleep(900)  # Wait for 15 minutes